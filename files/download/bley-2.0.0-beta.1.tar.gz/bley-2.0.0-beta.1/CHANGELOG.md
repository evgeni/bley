2.0.0-beta.1
============

 * New tool (bleygraph) for creating graphs
 * Rename bley.conf to bley.conf.example in the tarball
 * Rename README to README.md
 * Disable SPF Best Guess by default
 * Use Semantic Versioning (http://semver.org/)
 * Support for SQLite
 * Support for Exim
 * Support for Twisted 12, 13 and 14
 * Support for publicsuffix.org
 * Support for systemd
 * Support for postgrey comptatible whitelist_recipients and whitelist_clients lists
 * Support for configuring the cache age
 * Improve documentation
 * Add tests
 * Add example logcheck filter rules

0.1.5
=====
 * MySQL fixes
 * Add a manpage
 * Parse addresses case insensitive

0.1.4
=====
 * Reconnect to dead databases

0.1.3
=====
 * Strip non-ASCII chars from Postfix input

0.1.2
=====
 * RBL fixes

0.1.1
=====
 * MySQL fixes

0.1
===
 * Initial release
